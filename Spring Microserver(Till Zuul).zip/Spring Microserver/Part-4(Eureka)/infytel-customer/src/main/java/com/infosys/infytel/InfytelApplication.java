package com.infosys.infytel;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.client.discovery.EnableDiscoveryClient;
//For Customer
@SpringBootApplication
@EnableDiscoveryClient
public class InfytelApplication {

	public static void main(String[] args) {
		SpringApplication.run(InfytelApplication.class, args);
	}
}
