package com.infosys.infytel.service;

import java.util.ArrayList;
import java.util.List;


import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;



import com.infosys.infytel.dto.FriendFamilyDTO;


import com.infosys.infytel.entity.FriendFamily;

import com.infosys.infytel.repository.FriendFamilyRepository;
@Service
public class FriendFamilyService {
	Logger logger = LoggerFactory.getLogger(this.getClass());

	

	@Autowired
	FriendFamilyRepository friendRepo;

	

	// Save the friend details of a specific customer
	public void saveFriend(Long phoneNo, FriendFamilyDTO friendDTO) {
		logger.info("Creation request for customer {} with data {}", phoneNo, friendDTO);
		friendDTO.setPhoneNo(phoneNo);
		FriendFamily friend = friendDTO.createFriend();
		friendRepo.save(friend);
	}
	
	//#CREATED
	
	public List<Long>getSpecificFriends(Long phoneNo){
		
		List<Long>friendList= new ArrayList<>();
		List<FriendFamily>friends=friendRepo.getByPhoneNo(phoneNo);
		for(FriendFamily ff:friends) {
			friendList.add(ff.getFriendAndFamily());
		}
		return friendList;
	}

}
